<?php
header('Content-Type: text/html; charset=utf-8');

// 默认设置
$default_interval = 1;      // 默认检查间隔1秒
$default_motor_time = 1.5;  // 默认电机运行1.5秒

// 处理POST请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_content = file_exists('status.txt') ? file('status.txt', FILE_IGNORE_NEW_LINES) : ['OFF', $default_interval, $default_motor_time];
    $status = trim($current_content[0] ?? 'OFF');
    
    if (isset($_POST['interval'])) {
        $new_interval = intval($_POST['interval']);
        if ($new_interval < 1 || $new_interval > 86400) $new_interval = $default_interval;
        $current_motor_time = floatval($current_content[2] ?? $default_motor_time);
        file_put_contents('status.txt', $status . "\n" . $new_interval . "\n" . $current_motor_time);
    }
    
    if (isset($_POST['motor_time'])) {
        $new_motor_time = floatval($_POST['motor_time']);
        // 允许输入0.1到5.0之间的任意数字
        if ($new_motor_time < 0.1) $new_motor_time = 0.1;
        if ($new_motor_time > 5.0) $new_motor_time = 5.0;
        $current_interval = intval($current_content[1] ?? $default_interval);
        file_put_contents('status.txt', $status . "\n" . $current_interval . "\n" . $new_motor_time);
    }
    
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// 处理GET请求
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $status = ($action === 'on') ? 'ON' : 'OFF';
    
    $current_interval = $default_interval;
    $current_motor_time = $default_motor_time;
    if (file_exists('status.txt')) {
        $lines = file('status.txt', FILE_IGNORE_NEW_LINES);
        if (count($lines) >= 2) $current_interval = intval(trim($lines[1]));
        if (count($lines) >= 3) $current_motor_time = floatval(trim($lines[2]));
    }
    
    file_put_contents('status.txt', $status . "\n" . $current_interval . "\n" . number_format($current_motor_time, 1));
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// 读取当前设置
$current_status = 'OFF';
$current_interval = $default_interval;
$current_motor_time = $default_motor_time;

if (file_exists('status.txt')) {
    $lines = file('status.txt', FILE_IGNORE_NEW_LINES);
    $current_status = trim($lines[0] ?? 'OFF');
    if (count($lines) >= 2) $current_interval = intval(trim($lines[1]));
    if (count($lines) >= 3) $current_motor_time = floatval(trim($lines[2]));
}

if (!file_exists('status.txt')) {
    file_put_contents('status.txt', 'OFF' . "\n" . $default_interval . "\n" . $default_motor_time);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智能开关控制</title>
    <style>
        body { 
            font-family: "Microsoft YaHei", Arial, sans-serif; 
            text-align: center; 
            margin: 20px; 
            background: #f5f5f5;
            font-size: 16px;
        }
        .container { 
            background: white; 
            padding: 20px; 
            border-radius: 10px; 
            box-shadow: 0 0 10px rgba(0,0,0,0.1); 
            display: inline-block; 
            max-width: 100%;
            width: 100%;
            box-sizing: border-box;
        }
        .btn { 
            display: inline-block;
            padding: 15px 30px; 
            font-size: 18px; 
            margin: 8px; 
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            width: 45%;
            box-sizing: border-box;
        }
        .on { 
            background: #4CAF50; 
            color: white; 
        }
        .on:hover { 
            background: #45a049; 
        }
        .off { 
            background: #f44336; 
            color: white; 
        }
        .off:hover { 
            background: #da190b; 
        }
        .status {
            font-size: 20px;
            margin: 15px;
            padding: 12px;
            border-radius: 5px;
        }
        .status-on {
            background: #4CAF50;
            color: white;
        }
        .status-off {
            background: #f44336;
            color: white;
        }
        .setting-form {
            margin: 15px;
            padding: 12px;
            background: #f9f9f9;
            border-radius: 5px;
        }
        .setting-group {
            margin: 12px 0;
            text-align: left;
        }
        .setting-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            font-size: 16px;
        }
        .input-with-buttons {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .number-input {
            flex: 1;
            padding: 12px;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 5px;
            text-align: center;
            -webkit-appearance: none;
            -moz-appearance: textfield;
        }
        .number-input::-webkit-outer-spin-button,
        .number-input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        .step-btn {
            padding: 12px 16px;
            font-size: 18px;
            font-weight: bold;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            min-width: 50px;
        }
        .step-btn:hover {
            background: #0b7dda;
        }
        .submit-btn {
            padding: 12px 20px;
            font-size: 16px;
            background: #FF9800;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 8px;
            width: 100%;
        }
        .submit-btn:hover {
            background: #e68900;
        }
        .current-settings {
            margin: 15px 0;
            font-size: 16px;
            color: #666;
        }
        small {
            display: block;
            margin-top: 5px;
            color: #888;
            font-size: 14px;
        }
        
        /* 电脑端优化 */
        @media (min-width: 768px) {
            .container {
                max-width: 500px;
                width: auto;
            }
            .btn {
                width: auto;
                padding: 20px 40px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔌 智能开关控制</h1>
        
        <div class="status <?php echo $current_status == 'ON' ? 'status-on' : 'status-off'; ?>">
            <?php
            if ($current_status == 'ON') {
                echo '✅ 当前状态: 开启';
            } else {
                echo '❌ 当前状态: 关闭';
            }
            ?>
        </div>
        
        <div class="current-settings">
            <div>🕒 检查间隔: <strong><?php echo $current_interval; ?> 秒</strong></div>
            <div>⚙️ 电机运行时间: <strong><?php echo number_format($current_motor_time, 1); ?> 秒</strong></div>
        </div>
        
        <div>
            <a href="?action=on" class="btn on">开启开关</a>
            <a href="?action=off" class="btn off">关闭开关</a>
        </div>
        
        <div class="setting-form">
            <h3>系统设置</h3>
            
            <div class="setting-group">
                <form method="POST" id="intervalForm">
                    <label for="interval">检查间隔 (秒):</label>
                    <div class="input-with-buttons">
                        <button type="button" class="step-btn" onclick="changeInterval(-1)">-</button>
                        <input type="number" class="number-input" name="interval" id="interval" 
                               min="1" max="86400" value="<?php echo $current_interval; ?>"
                               onchange="validateInterval()">
                        <button type="button" class="step-btn" onclick="changeInterval(1)">+</button>
                    </div>
                    <button type="submit" class="submit-btn">设置检查间隔</button>
                    <small>ESP8266检查指令的频率 (1-86400秒)</small>
                </form>
            </div>
            
            <div class="setting-group">
                <form method="POST" id="motorTimeForm">
                    <label for="motor_time">电机运行时间 (秒):</label>
                    <div class="input-with-buttons">
                        <button type="button" class="step-btn" onclick="changeMotorTime(-0.1)">-</button>
                        <input type="number" class="number-input" name="motor_time" id="motor_time" 
                               min="0.1" max="5.0" step="0.1" 
                               value="<?php echo number_format($current_motor_time, 1); ?>"
                               onchange="validateMotorTime()">
                        <button type="button" class="step-btn" onclick="changeMotorTime(0.1)">+</button>
                    </div>
                    <button type="submit" class="submit-btn">设置电机时间</button>
                    <small>推杆伸出/收回的运行时间 (0.1-5.0秒，可输入任意数字)</small>
                </form>
            </div>
        </div>
        
        <div style="margin-top: 20px;">
            <a href="status.txt" target="_blank" style="color: #666; text-decoration: none;">📄 查看 status.txt 文件</a>
        </div>
    </div>

    <script>
        // 检查间隔控制函数
        function changeInterval(step) {
            const input = document.getElementById('interval');
            let value = parseInt(input.value) + step;
            if (value < 1) value = 1;
            if (value > 86400) value = 86400;
            input.value = value;
        }
        
        function validateInterval() {
            const input = document.getElementById('interval');
            let value = parseInt(input.value);
            if (value < 1) input.value = 1;
            if (value > 86400) input.value = 86400;
        }
        
        // 电机运行时间控制函数
        function changeMotorTime(step) {
            const input = document.getElementById('motor_time');
            let value = parseFloat(input.value) + step;
            // 限制小数位数
            value = Math.round(value * 10) / 10;
            if (value < 0.1) value = 0.1;
            if (value > 5.0) value = 5.0;
            input.value = value.toFixed(1);
        }
        
        function validateMotorTime() {
            const input = document.getElementById('motor_time');
            let value = parseFloat(input.value);
            if (value < 0.1) input.value = 0.1;
            if (value > 5.0) input.value = 5.0;
            // 确保正确的小数格式
            input.value = parseFloat(input.value).toFixed(1);
        }
        
        // 允许自由输入（移除输入限制）
        document.getElementById('motor_time').addEventListener('input', function(e) {
            let value = parseFloat(e.target.value);
            if (!isNaN(value)) {
                if (value < 0.1) value = 0.1;
                if (value > 5.0) value = 5.0;
                // 保持小数但不过度限制格式
                e.target.value = value;
            }
        });
    </script>
</body>
</html>